import unittest
from string_utils import StringManipulator

class TestStringManipulator(unittest.TestCase):
    def setUp(self):
        self.text = "Hello, world! 123"
        self.manipulator = StringManipulator(self.text)

    def test_reverse(self):
        self.assertEqual(self.manipulator.reverse(), "321 !dlrow ,olleH")

    def test_count_char(self):
        self.assertEqual(self.manipulator.count_char('l'), 3)

    def test_find_substring(self):
        self.assertEqual(self.manipulator.find_substring("lo"), [3])

    def test_to_upper(self):
        self.assertEqual(self.manipulator.to_upper(), "HELLO, WORLD! 123")

    def test_to_lower(self):
        self.assertEqual(self.manipulator.to_lower(), "hello, world! 123")

    def test_capitalize_first(self):
        self.assertEqual(self.manipulator.capitalize_first(), "Hello, world! 123")

    def test_title_case(self):
        self.assertEqual(self.manipulator.title_case(), "Hello, World! 123")

    def test_replace_substring(self):
        self.assertEqual(self.manipulator.replace_substring("world", "everyone"), "Hello, everyone! 123")

    def test_remove_whitespace(self):
        self.assertEqual(self.manipulator.remove_whitespace(), "Hello,world!123")

    def test_is_palindrome(self):
        self.assertFalse(self.manipulator.is_palindrome())
        palindrome_test = StringManipulator("A man a plan a canal panama")
        self.assertTrue(palindrome_test.is_palindrome())

    def test_levenshtein_distance(self):
        self.assertEqual(self.manipulator.levenshtein_distance("Hullo, world! 123"), 1)

    def test_contains(self):
        self.assertTrue(self.manipulator.contains("world"))
        self.assertFalse(self.manipulator.contains("moon"))

    def test_repeat(self):
        self.assertEqual(self.manipulator.repeat(2), "Hello, world! 123Hello, world! 123")

    def test_get_length(self):
        self.assertEqual(self.manipulator.get_length(), 17)

    def test_split_string(self):
        self.assertEqual(self.manipulator.split_string(), ["Hello,", "world!", "123"])

    def test_join_strings(self):
        self.assertEqual(self.manipulator.join_strings(["Hello", "world"], ", "), "Hello, world")

    def test_count_words(self):
        self.assertEqual(self.manipulator.count_words(), 3)

    def test_most_common_char(self):
        self.assertEqual(self.manipulator.most_common_char(), 'l')

    def test_is_anagram(self):
        self.assertTrue(StringManipulator("listen").is_anagram("silent"))
        self.assertFalse(StringManipulator("hello").is_anagram("world"))

if __name__ == '__main__':
    unittest.main()