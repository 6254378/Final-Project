class StringManipulator:
    def __init__(self, text):
        self.text = text

    def reverse(self):
        """Reverses the string."""
        return self.text[::-1]

    def count_char(self, char):
        """Counts occurrences of a character in the string."""
        return self.text.count(char)

    def find_substring(self, substring):
        """Finds all occurrences of a substring and returns their indices."""
        indices = []
        index = self.text.find(substring)
        while index != -1:
            indices.append(index)
            index = self.text.find(substring, index + 1)
        return indices

    def to_upper(self):
        """Converts all characters in the string to uppercase."""
        return self.text.upper()

    def to_lower(self):
        """Converts all characters in the string to lowercase."""
        return self.text.lower()

    def capitalize_first(self):
        """Capitalizes the first letter of the string."""
        return self.text.capitalize()

    def title_case(self):
        """Converts the first letter of each word to uppercase."""
        return self.text.title()

    def replace_substring(self, old, new):
        """Replaces all occurrences of a substring with another."""
        return self.text.replace(old, new)

    def remove_whitespace(self):
        """Removes all whitespace from the string."""
        return "".join(self.text.split())

    def is_palindrome(self):
        """Checks if the string is a palindrome."""
        cleaned_text = self.remove_whitespace().lower()
        return cleaned_text == cleaned_text[::-1]

    def levenshtein_distance(self, other):
        """Calculates the Levenshtein distance between two strings."""
        if len(self.text) < len(other):
            return StringManipulator(other).levenshtein_distance(self.text)

        if len(other) == 0:
            return len(self.text)

        previous_row = range(len(other) + 1)
        for i, c1 in enumerate(self.text):
            current_row = [i / 1]
            for j, c2 in enumerate(other):
                insertions = previous_row[j + 1] + 1
                deletions = current_row[j] + 1
                substitutions = previous_row[j] + (c1 != c2)
                current_row.append(min(insertions, deletions, substitutions))
            previous_row = current_row

        return previous_row[-1]

    def contains(self, substring):
        """Checks if the string contains a given substring."""
        return substring in self.text

    def repeat(self, times):
        """Repeats the string a specified number of times."""
        return self.text * times

    def get_length(self):
        """Returns the length of the string."""
        return len(self.text)

    def split_string(self, separator=" "):
        """Splits the string by a specified separator."""
        return self.text.split(separator)

    def join_strings(self, list_of_strings, separator=" "):
        """Joins a list of strings into one string with a separator."""
        return separator.join(list_of_strings)

    def count_words(self):
        """Counts the number of words in the string."""
        words = self.split_string()
        return len(words)

    def most_common_char(self):
        """Finds the most common character in the string."""
        from collections import Counter
        if not self.text:
            return None
        counter = Counter(self.text)
        return counter.most_common(1)[0][0]

    def is_anagram(self, other):
        """Checks if two strings are anagrams."""
        from collections import Counter
        return Counter(self.text) == Counter(other)